import json,tempfile,unittest
from pathlib import Path
import finalize_v7 as q
from pypdf.generic import DictionaryObject,NameObject,ArrayObject

class Guards(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.p=q.Pins(self.root)
    def tearDown(self):self.tmp.cleanup()
    def file(self,name,value):
        p=self.root/name;p.write_text(value);return {'path':name,'sha256':q.sha(p)}
    def visual(self):
        png=self.file('page.png','PNG witness fixture');pdf=self.file('doc.pdf','PDF witness fixture');report=self.file('review.md','Individually reviewed page 1 PASS')
        data={'pdf_sha256':pdf['sha256'],'pages':[{'page':1,'result':'PASS','individually_viewed_original_resolution':True,'png_sha256':png['sha256']}]}
        ledger=self.file('ledger.json',json.dumps(data))
        entry={'ledger':ledger,'record_pointer':'/pages/0','reviewed_page':1,'report':report,'reviewed_png':png,'reviewed_pdf':pdf}
        return entry,data
    def test_pin(self):self.p.pin(self.file('a','a'))
    def test_bad_hash(self):
        s=self.file('a','a');s['sha256']='0'*64
        with self.assertRaises(ValueError):self.p.pin(s)
    def test_mutation(self):
        self.p.pin(self.file('a','a'));(self.root/'a').write_text('b')
        with self.assertRaises(ValueError):self.p.reread()
    def test_escape(self):
        with self.assertRaises(ValueError):self.p.path('../outside')
    def test_symlink(self):
        self.file('a','a');(self.root/'link').symlink_to(self.root/'a')
        with self.assertRaises(ValueError):self.p.pin({'path':'link','sha256':q.sha(self.root/'a')})
    def test_visual_identity(self):
        e,_=self.visual();self.assertEqual(q.visual_page(self.p,self.root/'page.png',e)['lineage'],'full_png_byte_identity')
    def test_visual_changed_body(self):
        e,_=self.visual();self.file('new.png','different')
        with self.assertRaises(ValueError):q.visual_page(self.p,self.root/'new.png',e)
    def test_visual_not_seen(self):
        e,d=self.visual();d['pages'][0]['individually_viewed_original_resolution']=False;e['ledger']=self.file('ledger.json',json.dumps(d))
        with self.assertRaises(ValueError):q.visual_page(self.p,self.root/'page.png',e)
    def test_visual_wrong_pdf(self):
        e,d=self.visual();d['pdf_sha256']='0'*64;e['ledger']=self.file('ledger.json',json.dumps(d))
        with self.assertRaises(ValueError):q.visual_page(self.p,self.root/'page.png',e)
    def test_visual_wrong_page(self):
        e,_=self.visual();e['reviewed_page']=2
        with self.assertRaises(ValueError):q.visual_page(self.p,self.root/'page.png',e)
    def test_visual_missing_report(self):
        e,_=self.visual();(self.root/'review.md').unlink()
        with self.assertRaises(ValueError):q.visual_page(self.p,self.root/'page.png',e)
    def test_visual_no_pass(self):
        e,d=self.visual();d['pages'][0]['result']='PENDING';e['ledger']=self.file('ledger.json',json.dumps(d))
        with self.assertRaises(ValueError):q.visual_page(self.p,self.root/'page.png',e)
    def test_incomplete_config_no_output(self):
        self.file('config.json',json.dumps({'schema':'v7-final-qa-1','project_root':str(self.root),'documents':{}}))
        with self.assertRaises(ValueError):q.run(self.root/'config.json',self.root/'qa.json')
        self.assertFalse((self.root/'qa.json').exists())
    def test_collision(self):
        self.file('qa.json','original');self.file('config.json',json.dumps({'schema':'v7-final-qa-1','project_root':str(self.root)}))
        with self.assertRaises(ValueError):q.run(self.root/'config.json',self.root/'qa.json')
        self.assertEqual((self.root/'qa.json').read_text(),'original')
    def test_json_pointer(self):self.assertEqual(q.pointer({'a':[{'x':2}]},'/a/0/x'),2)
    def reader(self,embedded):
        font=DictionaryObject({NameObject('/Subtype'):NameObject('/TrueType'),NameObject('/BaseFont'):NameObject('/Fixture')})
        if embedded:font[NameObject('/FontDescriptor')]=DictionaryObject({NameObject('/FontFile2'):DictionaryObject()})
        resources=DictionaryObject({NameObject('/Font'):DictionaryObject({NameObject('/F1'):font})})
        return type('Reader',(),{'pages':[{'/Resources':resources}]})()
    def test_unembedded_font_rejected(self):
        with self.assertRaises(ValueError):q.embedded_fonts(self.reader(False))
    def test_embedded_font(self):self.assertEqual(q.embedded_fonts(self.reader(True)),['/Fixture'])
    def test_empty_fonts_rejected(self):
        with self.assertRaises(ValueError):q.embedded_fonts(type('Reader',(),{'pages':[{}]})())

if __name__=='__main__':unittest.main()
